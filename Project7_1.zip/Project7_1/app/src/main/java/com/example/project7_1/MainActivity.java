package com.example.project7_1;

import android.graphics.Color;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.View;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.project7_1.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    CoordinatorLayout coordinatorLayout1;
    View view;
    ConstraintLayout firstFragment1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        //길게 누르면 나오는 메뉴?
        firstFragment1 = findViewById(R.id.FirstFragment1);
        registerForContextMenu(firstFragment1);
    }

    //콘텐스트 메뉴 생성
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater menuInflater = getMenuInflater();
        if (v == firstFragment1) {
            menu.setHeaderTitle("배경색 변경");
            menuInflater.inflate(R.menu.context1_menu, menu);
        }
    }

    //콘텐스트 메뉴 선택 시 수행할 내용 기입
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        Button button_first = findViewById(R.id.button_first);
        switch (item.getItemId()) {
            case R.id.subRotate:
                button_first.setRotation(45);
                break;
            case R.id.subSize:
                button_first.setScaleX(2);
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    //옵션메뉴를 붙임
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);

        //메뉴 아이템 중에서 검색을 위해 정의한 아이템을 뷰 객체로 참조
        view = menu.findItem(R.id.search_button).getActionView();


        return true;
    }

    //옵션 항목을 선택했을 때
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        coordinatorLayout1 = findViewById(R.id.coordinator1);
        EditText editText = findViewById(R.id.edittext);
        if (editText != null) {
            editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                    Toast.makeText(getApplicationContext(), "입력되었습니다.", Toast.LENGTH_LONG).show();
                    return false;
                }
            });
        }

        switch (item.getItemId()) {
            case R.id.itemRed:
                coordinatorLayout1.setBackgroundColor(Color.RED);
                break;
            case R.id.itemBlue:
                coordinatorLayout1.setBackgroundColor(Color.BLUE);
                break;
            case R.id.menu_refresh:
                toast(); //사용자 정의 메소드
                break;
        }
        return true;
    }

    public void toast() {
        Toast msg = Toast.makeText(MainActivity.this, "refresh click", Toast.LENGTH_LONG);

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = (int) (Math.random() * metrics.widthPixels);
        int height = (int) (Math.random() * metrics.heightPixels);
        Log.i("tag", "width : " + width + "");
        Log.i("tag", "height : " + height + "");
        msg.setGravity(Gravity.LEFT | Gravity.TOP, width, height);
        msg.show();
    }
}