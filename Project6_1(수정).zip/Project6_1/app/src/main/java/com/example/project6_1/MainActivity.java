package com.example.project6_1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Chronometer;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TimePicker;

public class MainActivity extends AppCompatActivity {
    Chronometer chronometer;
    CalendarView calendarView1;
    TimePicker timePicker1;
    Button btnStart, btnEnd;
    RadioButton rdoCal, rdoTime;
    TextView textView1;
    int selectYear, selectMonth, selectDay, selectHour, selectMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("예약 앱");

        chronometer = findViewById(R.id.chronometer1);
        calendarView1 = findViewById(R.id.calendarView1);
        timePicker1 = findViewById(R.id.timePicker1);
        btnStart = findViewById(R.id.btnStart);
        btnEnd = findViewById(R.id.btnEnd);
        rdoCal = findViewById(R.id.rdoCal);
        rdoTime = findViewById(R.id.rdoTime);
        textView1 = findViewById(R.id.textView1); //String형임

        timePicker1.setVisibility(View.INVISIBLE); //화면에 안 보임
        calendarView1.setVisibility(View.INVISIBLE); //화면에 안 보임

        rdoCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendarView1.setVisibility(View.VISIBLE); //화면 보임
                timePicker1.setVisibility(View.INVISIBLE); //화면에 안 보임
            }
        });

        rdoTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timePicker1.setVisibility(View.VISIBLE); //화면 보임
                calendarView1.setVisibility(View.INVISIBLE); //화면에 안 보임
            }
        });

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chronometer.setBase(SystemClock.elapsedRealtime()); //예약에 걸린시간 예약시작을 누른 순간부터 타이머 시작
                chronometer.start(); //예약에 걸린 시간 시작
            }
        });

        btnEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chronometer.stop(); //예약에 걸린 시간 종료
                //예약 시간 표시
                //selectMonth에서 0부터 카운트를 세기 때문에 1을 더해줘야한다.
                textView1.setText(Integer.toString(selectYear)+ "년 " +Integer.toString(selectMonth+1) + "월 "+ Integer.toString(selectDay)+"일 "
                                    + Integer.toString(selectHour)+ "시 "+Integer.toString(selectMinute)+"분 ");
            }
        });
        
        //예약한 날짜 저장
        calendarView1.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
                selectYear = year;
                selectMonth = month;
                selectDay = day;
            }
        });
        
        //예약한 시간 저장
        timePicker1.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int hour, int minute) {
                selectHour = hour;
                selectMinute = minute;
            }
        });
        
        
    }
}