package com.example.mm3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.AlarmManager;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {

    HomeFragment homeFragment = new HomeFragment();
    AlarmFragment alarmFragment = new AlarmFragment();
    TempTurbFragment tempTurbFragment = new TempTurbFragment();
    FragmentManager fragmentManager = getSupportFragmentManager();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //맨위에 타이틀바 제거하기
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        //주어진 시간에 경고 메세지 발신

        BottomNavigationView bottomNavigationView = findViewById(R.id.menu_bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                FragmentTransaction transaction = fragmentManager.beginTransaction();
                //버튼을 클릭할때
                switch (item.getItemId()){
                    case R.id.menu_home:
                        //화면 교체는 replace를 이용
                        transaction.replace(R.id.menu_frameLayout, homeFragment).commit();
                        break;
                    case R.id.menu_alarm:
                        transaction.replace(R.id.menu_frameLayout, alarmFragment).commit();
                        break;
                    case R.id.menu_tempTurb:
                        transaction.replace(R.id.menu_frameLayout, tempTurbFragment).commit();
                        break;
                }
                return false;
            }
        });
    }

}