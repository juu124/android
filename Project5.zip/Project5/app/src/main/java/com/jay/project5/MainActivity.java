package com.jay.project5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    LinearLayout linearLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main); 주석처리를 했기 때문에 activity_main.xml은 쓸모가 없다
        linearLayout = new LinearLayout(MainActivity.this); //리니어를 불러온다 스크린에(상위화면)  this라고 적어도 무방
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setBackgroundColor(Color.CYAN);

        Button btn = new Button(MainActivity.this);//버튼도 메인 스크린에 불러온다 this라고 적어도 무방
        btn.setText("추가");

        LinearLayout.LayoutParams btnLayoutParams = new LinearLayout.LayoutParams(200, 200);
        linearLayout.addView(btn, btnLayoutParams); //레이아웃에 btn(버튼)추가

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView textView = new TextView(MainActivity.this); //mainActivity.this로 이름을 구체적으로 명시해야한다. onclick메소드라서 this라고 하면 잘 모른다.
                textView.setBackgroundColor(Color.YELLOW);
                LinearLayout.LayoutParams textlayoutParams = new LinearLayout.LayoutParams(200,200);
                textlayoutParams.setMargins(20,10,0,10);
                linearLayout.addView(textView, textlayoutParams);
            }
        });
        //액티비티 이동버튼 추가
        Button btnMove = new Button(this); //메인 액티비티화면에 버튼 객체 생성
        btnMove.setText("액티비티 이동");
        LinearLayout.LayoutParams btnMovelayoutParams = new LinearLayout.LayoutParams(200, 200);
        linearLayout.addView(btnMove, btnMovelayoutParams); //레이아웃에 btn(버튼)추가

        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //명시적 인텐트 (특정 대상을 지정)
                Intent i =  new Intent(MainActivity.this, RelativeActivity.class);
                startActivity(i);
            }
        });

        //프레임 레이아웃 이동버튼 추가
        Button btnFrame = new Button(this); //메인 액티비티화면에 버튼 객체 생성
        btnFrame.setText("프레임 레이아웃 이동");
        LinearLayout.LayoutParams btnFramelayoutParams = new LinearLayout.LayoutParams(200, 200);
        linearLayout.addView(btnFrame, btnFramelayoutParams); //레이아웃에 btn(버튼)추가

        btnFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //명시적 인텐트 (특정 대상을 지정)
                Intent i =  new Intent(MainActivity.this, FrameActivity.class);
                startActivity(i);
            }
        });

        setContentView(linearLayout); //상위 레이아웃(위에서 만든 모든 레이아웃 출력)

    }
}